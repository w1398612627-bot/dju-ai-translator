const express = require("express");

const cors = require("cors");

const OpenAI = require("openai");

const app = express();

app.use(cors());

app.use(
    express.json({
        limit: "10mb"
    })
);

// DeepSeek API
const client = new OpenAI({

    apiKey:
        "sk-042a5dcb84bb4809a01fd9c462fba8b4",

    baseURL:
        "https://api.deepseek.com"

});

// 缓存
const cache = new Map();

// AI翻译
async function translateText(text) {

    // 缓存命中
    if (cache.has(text)) {

        return cache.get(text);

    }

    try {

        const response =
            await client.chat.completions.create({

                model: "deepseek-chat",

                messages: [

                    {
                        role: "system",

                        content:
`
你是韩国大学门户网站专业翻译器。

要求：

1. 翻译成自然中文
2. 保持教务系统术语准确
3. 不要解释
4. 不要添加额外内容
5. 保持网页UI简洁
6. 像真正中文网页
7. 保持按钮风格简短

示例：

수강신청 → 选课
성적조회 → 成绩查询
공지사항 → 公告
장학금 → 奖学金
도서관 → 图书馆
`
                    },

                    {
                        role: "user",

                        content: text
                    }

                ],

                temperature: 0.2

            });

        const translated =
            response.choices[0]
                .message.content
                .trim();

        // 写入缓存
        cache.set(
            text,
            translated
        );

        return translated;

    } catch (err) {

        console.log(
            "翻译失败:",
            err.message
        );

        return text;

    }

}

// 批量翻译接口
app.post(
    "/translate-batch",
    async (req, res) => {

        try {

            const texts =
                req.body.texts || [];

            const translatedTexts =
                [];

            // 小批量稳定AI翻译
            for (const text of texts) {

                const translated =
                    await translateText(
                        text
                    );

                translatedTexts.push(
                    translated
                );

            }

            res.json({
                translatedTexts
            });

        } catch (err) {

            console.log(err);

            res.json({
                translatedTexts:
                    req.body.texts || []
            });

        }

    }
);

app.listen(3000, () => {

    console.log(
        "DeepSeek AI翻译服务器运行：http://localhost:3000"
    );

});