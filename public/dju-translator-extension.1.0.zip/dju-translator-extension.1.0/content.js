// =========================
// DJU AI Translator
// Ultimate Professional Edition
// =========================

let translated = false;

const originalMap = new Map();

const translatedNodes = new Set();

const translationCache =
    JSON.parse(
        localStorage.getItem(
            "dju_translation_cache"
        ) || "{}"
    );

// =========================
// 术语库
// =========================

const dictionary = {

    // 星期
    "월": "周一",
    "화": "周二",
    "수": "周三",
    "목": "周四",
    "금": "周五",
    "토": "周六",
    "일": "周日",

    // 教务系统
    "수강신청": "选课",
    "성적조회": "成绩查询",
    "공지사항": "公告",
    "장학금": "奖学金",
    "도서관": "图书馆",
    "학생서비스": "学生服务",
    "졸업": "毕业",
    "검색": "搜索",
    "로그아웃": "注销",
    "시간표": "课表",
    "학기": "学期",
    "학점": "学分",
    "전공": "专业",
    "교양": "通识",
    "재수강": "重修",
    "출석": "出勤",
    "결석": "缺勤",
    "시험": "考试",
    "과제": "作业",
    "강의": "课程",
    "메인페이지": "主页",
    "마이페이지": "我的页面",
    "학생": "学生",
    "교수": "教授",
    "학번": "学号",
    "비밀번호": "密码",
    "교양영역": "通识领域",
    "이수학점": "已修学分",
    "졸업요건": "毕业要求",
    "전필": "专业必修",
    "전선": "专业选修",
    "교양": "通识",
    "학부": "学院"

};

// =========================
// 保存缓存
// =========================

function saveCache() {

    localStorage.setItem(
        "dju_translation_cache",
        JSON.stringify(
            translationCache
        )
    );

}

// =========================
// 批量翻译
// =========================

async function batchTranslate(texts) {

    try {

        const uncachedTexts = [];

        const uncachedIndexes = [];

        const results = [...texts];

        texts.forEach((text, index) => {

            if (
                dictionary[text]
            ) {

                results[index] =
                    dictionary[text];

                return;

            }

            if (
                translationCache[text]
            ) {

                results[index] =
                    translationCache[text];

            } else {

                uncachedTexts.push(text);

                uncachedIndexes.push(index);

            }

        });

        if (
            uncachedTexts.length === 0
        ) {

            return results;

        }

        const response = await fetch(
            "http://localhost:3000/translate-batch",
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body: JSON.stringify({
                    texts: uncachedTexts
                })
            }
        );

        const data =
            await response.json();

        const translatedTexts =
            data.translatedTexts || [];

        translatedTexts.forEach(
            (translated, i) => {

                const original =
                    uncachedTexts[i];

                translationCache[
                    original
                ] = translated;

                saveCache();

                results[
                    uncachedIndexes[i]
                ] = translated;

            }
        );

        return results;

    } catch (err) {

        console.log(err);

        return texts;

    }

}

// =========================
// 获取文本节点
// =========================

function getAllTextNodes(root = document.body) {

    const walker =
        document.createTreeWalker(
            root,
            NodeFilter.SHOW_TEXT,
            null,
            false
        );

    const nodes = [];

    let node;

    while (
        (node = walker.nextNode())
    ) {

        try {

            const parent =
                node.parentElement;

            if (!parent) {
                continue;
            }

            if (
                parent.closest(
                    "#dju-translator-ui"
                )
            ) {
                continue;
            }

            if (
                translatedNodes.has(node)
            ) {
                continue;
            }

            const tag =
                parent.tagName;

            if (
                [
                    "SCRIPT",
                    "STYLE",
                    "NOSCRIPT",
                    "TEXTAREA",
                    "INPUT",
                    "OPTION"
                ].includes(tag)
            ) {
                continue;
            }

            const text =
                node.textContent.trim();

            if (!text) {
                continue;
            }

            if (
                text.length > 200
            ) {
                continue;
            }

            if (
                !/[가-힣]/.test(text)
            ) {
                continue;
            }

            const style =
                window.getComputedStyle(
                    parent
                );

            if (
                style.display === "none" ||
                style.visibility === "hidden"
            ) {
                continue;
            }

            // 强制特殊区域
            const importantTags = [
                "TD",
                "TH",
                "SPAN",
                "DIV",
                "A",
                "LI"
            ];

            if (
                importantTags.includes(tag)
            ) {

                nodes.push(node);

                continue;

            }

            nodes.push(node);

        } catch {}

    }

    return nodes;

}

// =========================
// 更新状态
// =========================

function updateStatus(
    text,
    percent = 0
) {

    const status =
        document.getElementById(
            "dju-status"
        );

    const bar =
        document.getElementById(
            "dju-progress-bar"
        );

    if (status) {

        status.innerText = text;

    }

    if (bar) {

        requestAnimationFrame(() => {

            bar.style.width =
                `${percent}%`;

        });

    }

}

// =========================
// 翻译普通节点
// =========================

async function translateNodes(nodes) {

    let completed = 0;

    const total =
        nodes.length;

    const BATCH_SIZE = 15;

    for (
        let i = 0;
        i < nodes.length;
        i += BATCH_SIZE
    ) {

        const batch =
            nodes.slice(
                i,
                i + BATCH_SIZE
            );

        const texts =
            batch.map(
                node =>
                    node.textContent.trim()
            );

        const translatedTexts =
            await batchTranslate(
                texts
            );

        batch.forEach(
            (node, index) => {

                try {

                    const translated =
                        translatedTexts[
                            index
                        ];

                    if (
                        !translated
                    ) {
                        return;
                    }

                    if (
                        !originalMap.has(node)
                    ) {

                        originalMap.set(
                            node,
                            node.textContent
                        );

                    }

                    if (
                        node.parentElement
                    ) {

                        node.parentElement.title =
                            texts[index];

                    }

                    node.textContent =
                        translated;

                    translatedNodes.add(
                        node
                    );

                    completed++;

                } catch {}

            }
        );

        const percent =
            Math.floor(
                (completed /
                    total) *
                100
            );

        updateStatus(
            percent >= 100
                ? "翻译完成"
                : `AI翻译中 ${percent}%`,
            percent
        );

        await new Promise(
            resolve =>
                setTimeout(
                    resolve,
                    5
                )
        );

    }

}

// =========================
// 强制翻译特殊区域
// =========================

async function translateSpecialElements() {

    const selectors = [

        "td",
        "th",
        "span",
        "div",
        "a",
        "li"

    ];

    const elements =
        document.querySelectorAll(
            selectors.join(",")
        );

    for (const el of elements) {

        try {

            if (
                el.closest(
                    "#dju-translator-ui"
                )
            ) {
                continue;
            }

            if (
                el.children.length > 0
            ) {
                continue;
            }

            const text =
                el.innerText?.trim();

            if (!text) {
                continue;
            }

            if (
                !/[가-힣]/.test(text)
            ) {
                continue;
            }

            if (
                text.length > 100
            ) {
                continue;
            }

            if (
                translatedNodes.has(el)
            ) {
                continue;
            }

            const translated =
                (
                    await batchTranslate(
                        [text]
                    )
                )[0];

            if (
                translated
            ) {

                originalMap.set(
                    el,
                    text
                );

                el.innerText =
                    translated;

                translatedNodes.add(
                    el
                );

            }

        } catch {}

    }

}

// =========================
// 翻译网页
// =========================

async function translatePage() {

    if (translated) {
        return;
    }

    translated = true;

    translatedNodes.clear();

    updateStatus(
        "扫描网页中...",
        5
    );

    const nodes =
        getAllTextNodes();

    updateStatus(
        `发现 ${nodes.length} 个文本`,
        10
    );

    await translateNodes(
        nodes
    );

    await translateSpecialElements();

}

// =========================
// 恢复原文
// =========================

function restorePage() {

    try {

        translatedNodes.forEach(node => {

            try {

                if (
                    originalMap.has(node)
                ) {

                    if (
                        node.nodeType === 3
                    ) {

                        node.textContent =
                            originalMap.get(node);

                    } else {

                        node.innerText =
                            originalMap.get(node);

                    }

                }

            } catch {}

        });

        translatedNodes.clear();

        translated = false;

        const progressBar =
            document.getElementById(
                "dju-progress-bar"
            );

        if (progressBar) {

            progressBar.style.width =
                "0%";

        }

        updateStatus(
            "已恢复原文",
            0
        );

    } catch (err) {

        console.log(err);

    }

}

// =========================
// 动态监听
// =========================

function observePage() {

    const observer =
        new MutationObserver(
            async mutations => {

                if (!translated) {
                    return;
                }

                for (const mutation of mutations) {

                    for (const node of mutation.addedNodes) {

                        try {

                            if (
                                node.nodeType !== 1
                            ) {
                                continue;
                            }

                            const textNodes =
                                getAllTextNodes(
                                    node
                                );

                            if (
                                textNodes.length
                            ) {

                                await translateNodes(
                                    textNodes
                                );

                            }

                            await translateSpecialElements();

                        } catch {}

                    }

                }

            }
        );

    observer.observe(
        document.body,
        {
            childList: true,
            subtree: true
        }
    );

}

// =========================
// 创建高级UI
// =========================

function createUI() {

    if (
        document.getElementById(
            "dju-translator-ui"
        )
    ) {
        return;
    }

    const style =
        document.createElement(
            "style"
        );

    style.textContent = `

@keyframes djuGradient {

    0% {
        background-position: 0%;
    }

    100% {
        background-position: 200%;
    }

}

`;

    document.head.appendChild(
        style
    );

    const box =
        document.createElement(
            "div"
        );

    box.id =
        "dju-translator-ui";

    box.style.position =
        "fixed";

    box.style.top =
        "20px";

    box.style.right =
        "20px";

    box.style.width =
        "280px";

    box.style.minWidth =
        "220px";

    box.style.minHeight =
        "120px";

    box.style.resize =
        "both";

    box.style.overflow =
        "auto";

    box.style.zIndex =
        "999999";

    box.style.background =
        "rgba(15,15,20,0.72)";

    box.style.border =
        "1px solid rgba(255,255,255,0.08)";

    box.style.backdropFilter =
        "blur(18px)";

    box.style.color =
        "#fff";

    box.style.padding =
        "16px";

    box.style.borderRadius =
        "20px";

    box.style.boxShadow =
        "0 10px 35px rgba(0,0,0,0.35)";

    box.style.fontFamily =
        "Inter, sans-serif";

    box.style.userSelect =
        "none";

    box.style.transform =
        "translateY(-20px) scale(0.95)";

    box.style.opacity =
        "0";

    setTimeout(() => {

        box.style.transition =
            "all 0.35s cubic-bezier(0.22,1,0.36,1)";

        box.style.transform =
            "translateY(0) scale(1)";

        box.style.opacity =
            "1";

    }, 50);

    // 标题栏
    const dragBar =
        document.createElement(
            "div"
        );

    dragBar.innerText =
        "DJU AI Translator";

    dragBar.style.fontSize =
        "18px";

    dragBar.style.fontWeight =
        "700";

    dragBar.style.marginBottom =
        "14px";

    dragBar.style.cursor =
        "move";

    dragBar.style.display =
        "flex";

    dragBar.style.alignItems =
        "center";

    dragBar.style.justifyContent =
        "space-between";

    const resizeTip =
        document.createElement(
            "span"
        );

    resizeTip.innerText =
        "↘";

    resizeTip.style.opacity =
        "0.5";

    dragBar.appendChild(
        resizeTip
    );

    // 状态
    const status =
        document.createElement(
            "div"
        );

    status.id =
        "dju-status";

    status.innerText =
        "等待翻译";

    status.style.fontSize =
        "13px";

    status.style.opacity =
        "0.85";

    status.style.marginBottom =
        "10px";

    // 进度条
    const progressBg =
        document.createElement(
            "div"
        );

    progressBg.style.width =
        "100%";

    progressBg.style.height =
        "6px";

    progressBg.style.background =
        "rgba(255,255,255,0.08)";

    progressBg.style.borderRadius =
        "999px";

    progressBg.style.overflow =
        "hidden";

    progressBg.style.marginBottom =
        "16px";

    const progressBar =
        document.createElement(
            "div"
        );

    progressBar.id =
        "dju-progress-bar";

    progressBar.style.width =
        "0%";

    progressBar.style.height =
        "100%";

    progressBar.style.background =
        "linear-gradient(90deg,#00c6ff,#0072ff,#00c6ff)";

    progressBar.style.backgroundSize =
        "200% 100%";

    progressBar.style.animation =
        "djuGradient 2s linear infinite";

    progressBar.style.transition =
        "width 0.25s ease";

    progressBg.appendChild(
        progressBar
    );

    // 按钮
    const btnWrap =
        document.createElement(
            "div"
        );

    btnWrap.style.display =
        "flex";

    btnWrap.style.gap =
        "10px";

    const btn =
        document.createElement(
            "button"
        );

    btn.innerText =
        "开始翻译";

    btn.onclick =
        translatePage;

    const restoreBtn =
        document.createElement(
            "button"
        );

    restoreBtn.innerText =
        "恢复原文";

    restoreBtn.onclick =
        restorePage;

    [btn, restoreBtn]
        .forEach(button => {

            button.style.flex =
                "1";

            button.style.border =
                "none";

            button.style.padding =
                "10px";

            button.style.borderRadius =
                "12px";

            button.style.cursor =
                "pointer";

            button.style.fontWeight =
                "600";

            button.style.transition =
                "all 0.2s ease";

            button.onmouseenter =
                () => {

                    button.style.transform =
                        "translateY(-2px) scale(1.02)";

                    button.style.boxShadow =
                        "0 6px 18px rgba(0,0,0,0.25)";

                };

            button.onmouseleave =
                () => {

                    button.style.transform =
                        "translateY(0) scale(1)";

                    button.style.boxShadow =
                        "none";

                };

        });

    btn.style.background =
        "linear-gradient(90deg,#00c6ff,#0072ff)";

    btn.style.color =
        "#fff";

    restoreBtn.style.background =
        "rgba(255,255,255,0.08)";

    restoreBtn.style.color =
        "#fff";

    btnWrap.appendChild(btn);

    btnWrap.appendChild(
        restoreBtn
    );

    // Footer
    const footer =
        document.createElement(
            "div"
        );

    footer.innerText =
        "AI Smart Translation";

    footer.style.fontSize =
        "11px";

    footer.style.opacity =
        "0.5";

    footer.style.marginTop =
        "14px";

    footer.style.textAlign =
        "center";

    // 添加
    box.appendChild(dragBar);

    box.appendChild(status);

    box.appendChild(progressBg);

    box.appendChild(btnWrap);

    box.appendChild(footer);

    document.body.appendChild(
        box
    );

    // 拖拽
    let isDragging = false;

    let offsetX = 0;

    let offsetY = 0;

    dragBar.addEventListener(
        "mousedown",
        e => {

            isDragging = true;

            offsetX =
                e.clientX -
                box.offsetLeft;

            offsetY =
                e.clientY -
                box.offsetTop;

        }
    );

    document.addEventListener(
        "mousemove",
        e => {

            if (!isDragging) {
                return;
            }

            requestAnimationFrame(() => {

                box.style.left =
                    `${e.clientX - offsetX}px`;

                box.style.top =
                    `${e.clientY - offsetY}px`;

                box.style.right =
                    "auto";

            });

        }
    );

    document.addEventListener(
        "mouseup",
        () => {

            isDragging = false;

        }
    );

}

// =========================
// 自动翻译
// =========================

window.addEventListener(
    "load",
    () => {

        setTimeout(
            translatePage,
            1200
        );

    }
);

// =========================
// 初始化
// =========================

createUI();

observePage();