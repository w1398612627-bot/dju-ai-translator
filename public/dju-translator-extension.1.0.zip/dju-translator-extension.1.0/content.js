// =========================
// DJU AI Translator
// Stable Ultimate Edition
// ONLY TEXT NODE VERSION
// =========================

let translated = false;

const originalMap = new Map();

const translatedNodes = new Set();

const translationCache =
    JSON.parse(
        localStorage.getItem(
            "dju_translation_cache"
        ) || "{}"
    );

// =========================
// 保存缓存
// =========================

function saveCache() {

    localStorage.setItem(
        "dju_translation_cache",
        JSON.stringify(
            translationCache
        )
    );

}

// =========================
// 批量翻译
// =========================

async function batchTranslate(texts) {

    return new Promise(resolve => {

        chrome.runtime.sendMessage(
            {
                type: "translateBatch",
                texts
            },

            response => {

                if (
                    response &&
                    response.success
                ) {

                    resolve(
                        response.result
                    );

                } else {

                    resolve(texts);

                }

            }
        );

    });

}

// =========================
// 获取所有文本节点
// =========================

function getAllTextNodes(root = document.body) {

    const walker =
        document.createTreeWalker(
            root,
            NodeFilter.SHOW_TEXT,
            null,
            false
        );

    const nodes = [];

    let node;

    while (
        (node = walker.nextNode())
    ) {

        try {

            const parent =
                node.parentElement;

            if (!parent) {
                continue;
            }

            // 插件UI跳过
            if (
                parent.closest(
                    "#dju-translator-ui"
                )
            ) {
                continue;
            }

            // 已翻译跳过
            if (
                translatedNodes.has(node)
            ) {
                continue;
            }

            const tag =
                parent.tagName;

            // 禁止区域
            if (
                [
                    "SCRIPT",
                    "STYLE",
                    "NOSCRIPT",
                    "TEXTAREA",
                    "INPUT",
                    "OPTION"
                ].includes(tag)
            ) {
                continue;
            }

            const text =
                node.textContent.trim();

            if (!text) {
                continue;
            }

            // 太长跳过
            if (
                text.length > 1500
            ) {
                continue;
            }

            // 无韩文跳过
            if (
                !/[가-힣]/.test(text)
            ) {
                continue;
            }

            // 纯数字跳过
            if (
                /^[0-9\s\-:/.]+$/.test(text)
            ) {
                continue;
            }

            // 特殊符号过多跳过
            if (
                text.replace(/[가-힣a-zA-Z0-9]/g, "")
                    .length >
                text.length * 0.6
            ) {
                continue;
            }

            const style =
                window.getComputedStyle(
                    parent
                );

            if (
                style.display === "none" ||
                style.visibility === "hidden"
            ) {
                continue;
            }

            nodes.push(node);

        } catch {}

    }

    return nodes;

}

// =========================
// 更新状态
// =========================

function updateStatus(
    text,
    percent = 0
) {

    const status =
        document.getElementById(
            "dju-status"
        );

    const bar =
        document.getElementById(
            "dju-progress-bar"
        );

    if (status) {

        status.innerText = text;

    }

    if (bar) {

        requestAnimationFrame(() => {

            bar.style.width =
                `${percent}%`;

        });

    }

}

// =========================
// 翻译节点
// =========================

async function translateNodes(nodes) {

    let completed = 0;

    const total =
        nodes.length;

    // 稳定批量
    const BATCH_SIZE = 8;

    for (
        let i = 0;
        i < nodes.length;
        i += BATCH_SIZE
    ) {

        const batch =
            nodes.slice(
                i,
                i + BATCH_SIZE
            );

        const texts =
            batch.map(
                node =>
                    node.textContent.trim()
            );

        const translatedTexts =
            [];

        const needTranslate =
            [];

        const needIndex =
            [];

        // 缓存优先
        texts.forEach(
            (text, index) => {

                if (
                    translationCache[text]
                ) {

                    translatedTexts[index] =
                        translationCache[text];

                } else {

                    needTranslate.push(text);

                    needIndex.push(index);

                }

            }
        );

        // API翻译
        if (
            needTranslate.length
        ) {

            const apiResults =
                await batchTranslate(
                    needTranslate
                );

            apiResults.forEach(
                (translated, idx) => {

                    const realIndex =
                        needIndex[idx];

                    translatedTexts[
                        realIndex
                    ] = translated;

                    translationCache[
                        needTranslate[idx]
                    ] = translated;

                }
            );

            saveCache();

        }

        // 应用翻译
        batch.forEach(
            (node, index) => {

                try {

                    const translated =
                        translatedTexts[
                            index
                        ];

                    if (
                        !translated
                    ) {
                        return;
                    }

                    // 防止爆网页
                    if (
                        translated.includes(
                            "---TEXT---"
                        )
                    ) {
                        return;
                    }

                    if (
                        translated.length > 3000
                    ) {
                        return;
                    }

                    if (
                        !originalMap.has(node)
                    ) {

                        originalMap.set(
                            node,
                            node.textContent
                        );

                    }

                    // ONLY TEXT NODE
                    node.textContent =
                        translated;

                    translatedNodes.add(
                        node
                    );

                    completed++;

                } catch {}

            }
        );

        const percent =
            Math.floor(
                (completed /
                    total) *
                100
            );

        updateStatus(
            percent >= 100
                ? "翻译完成"
                : `AI翻译中 ${percent}%`,
            percent
        );

        await new Promise(
            resolve =>
                setTimeout(
                    resolve,
                    30
                )
        );

    }

}

// =========================
// 翻译网页
// =========================

async function translatePage() {

    if (translated) {
        return;
    }

    translated = true;

    translatedNodes.clear();

    updateStatus(
        "扫描网页中...",
        5
    );

    const nodes =
        getAllTextNodes();

    updateStatus(
        `发现 ${nodes.length} 个文本`,
        10
    );

    await translateNodes(
        nodes
    );

    // 二次扫描
    const remainNodes =
        getAllTextNodes();

    if (
        remainNodes.length
    ) {

        await translateNodes(
            remainNodes
        );

    }

}

// =========================
// 恢复原文
// =========================

function restorePage() {

    try {

        translatedNodes.forEach(node => {

            try {

                if (
                    originalMap.has(node)
                ) {

                    node.textContent =
                        originalMap.get(node);

                }

            } catch {}

        });

        translatedNodes.clear();

        translated = false;

        const progressBar =
            document.getElementById(
                "dju-progress-bar"
            );

        if (progressBar) {

            progressBar.style.width =
                "0%";

        }

        updateStatus(
            "已恢复原文",
            0
        );

    } catch {}

}

// =========================
// 动态监听
// =========================

function observePage() {

    const observer =
        new MutationObserver(
            async mutations => {

                if (!translated) {
                    return;
                }

                for (const mutation of mutations) {

                    for (const node of mutation.addedNodes) {

                        try {

                            if (
                                node.nodeType !== 1
                            ) {
                                continue;
                            }

                            const textNodes =
                                getAllTextNodes(
                                    node
                                );

                            if (
                                textNodes.length
                            ) {

                                await translateNodes(
                                    textNodes
                                );

                            }

                        } catch {}

                    }

                }

            }
        );

    observer.observe(
        document.body,
        {
            childList: true,
            subtree: true
        }
    );

}

// =========================
// 创建UI
// =========================

function createUI() {

    if (
        document.getElementById(
            "dju-translator-ui"
        )
    ) {
        return;
    }

    const box =
        document.createElement(
            "div"
        );

    box.id =
        "dju-translator-ui";

    box.style.position =
        "fixed";

    box.style.top =
        "20px";

    box.style.right =
        "20px";

    box.style.width =
        "280px";

    box.style.zIndex =
        "999999";

    box.style.background =
        "rgba(20,20,25,0.78)";

    box.style.backdropFilter =
        "blur(18px)";

    box.style.color =
        "#fff";

    box.style.padding =
        "16px";

    box.style.borderRadius =
        "20px";

    box.style.boxShadow =
        "0 8px 30px rgba(0,0,0,0.35)";

    box.style.fontFamily =
        "Inter,sans-serif";

    // 标题
    const title =
        document.createElement(
            "div"
        );

    title.innerText =
        "DJU AI Translator";

    title.style.fontSize =
        "18px";

    title.style.fontWeight =
        "700";

    title.style.marginBottom =
        "14px";

    // 状态
    const status =
        document.createElement(
            "div"
        );

    status.id =
        "dju-status";

    status.innerText =
        "等待翻译";

    status.style.fontSize =
        "13px";

    status.style.opacity =
        "0.85";

    status.style.marginBottom =
        "10px";

    // 进度条
    const progressBg =
        document.createElement(
            "div"
        );

    progressBg.style.width =
        "100%";

    progressBg.style.height =
        "6px";

    progressBg.style.background =
        "rgba(255,255,255,0.08)";

    progressBg.style.borderRadius =
        "999px";

    progressBg.style.overflow =
        "hidden";

    progressBg.style.marginBottom =
        "16px";

    const progressBar =
        document.createElement(
            "div"
        );

    progressBar.id =
        "dju-progress-bar";

    progressBar.style.width =
        "0%";

    progressBar.style.height =
        "100%";

    progressBar.style.background =
        "linear-gradient(90deg,#00c6ff,#0072ff)";

    progressBar.style.transition =
        "width .25s ease";

    progressBg.appendChild(
        progressBar
    );

    // 按钮区域
    const btnWrap =
        document.createElement(
            "div"
        );

    btnWrap.style.display =
        "flex";

    btnWrap.style.gap =
        "10px";

    // 翻译按钮
    const btn =
        document.createElement(
            "button"
        );

    btn.innerText =
        "开始翻译";

    btn.onclick =
        translatePage;

    // 恢复按钮
    const restoreBtn =
        document.createElement(
            "button"
        );

    restoreBtn.innerText =
        "恢复原文";

    restoreBtn.onclick =
        restorePage;

    [btn, restoreBtn]
        .forEach(button => {

            button.style.flex =
                "1";

            button.style.border =
                "none";

            button.style.padding =
                "10px";

            button.style.borderRadius =
                "12px";

            button.style.cursor =
                "pointer";

            button.style.fontWeight =
                "600";

        });

    btn.style.background =
        "linear-gradient(90deg,#00c6ff,#0072ff)";

    btn.style.color =
        "#fff";

    restoreBtn.style.background =
        "rgba(255,255,255,0.08)";

    restoreBtn.style.color =
        "#fff";

    btnWrap.appendChild(btn);

    btnWrap.appendChild(
        restoreBtn
    );

    // Footer
    const footer =
        document.createElement(
            "div"
        );

    footer.innerText =
        "AI Smart Translation";

    footer.style.fontSize =
        "11px";

    footer.style.opacity =
        "0.5";

    footer.style.marginTop =
        "14px";

    footer.style.textAlign =
        "center";

    box.appendChild(title);

    box.appendChild(status);

    box.appendChild(progressBg);

    box.appendChild(btnWrap);

    box.appendChild(footer);

    document.body.appendChild(
        box
    );

}

// =========================
// 初始化
// =========================

createUI();

observePage();