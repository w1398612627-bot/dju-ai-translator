// =====================================================
// DJU AI Translator – Production Ready v4
// 全节点 | 可恢复 | 可视优先 | 空闲调度
// =====================================================
(() => {
    "use strict";

    // ---------- Polyfill ----------
    if (!window.requestIdleCallback) {
        window.requestIdleCallback = function (cb) {
            return setTimeout(() => {
                cb({ didTimeout: false, timeRemaining: () => 50 });
            }, 1);
        };
    }
    if (!window.cancelIdleCallback) {
        window.cancelIdleCallback = function (id) {
            clearTimeout(id);
        };
    }

    // ---------- Global State ----------
    const state = {
        active: false,
        translating: false,
        processing: false,

        visibleQueue: [],
        backgroundQueue: [],

        observer: null,
        intersectionObserver: null,

        total: 0,
        completed: 0,

        statusEl: null,
        progressEl: null,

        mutationTimer: null,
        cacheSaveTimer: null,
    };

    // ---------- Modified Records ----------
    let translatedTextNodes = new WeakSet();         // 已翻译文本节点标记
    const modifiedTextNodes = new Map();             // textNode -> original
    const modifiedAttrElements = new Map();          // element -> { attr: original }

    // ---------- Cache ----------
    const CACHE_KEY = "dju_translation_v4";
    const MAX_CACHE = 3000;
    let translationCache = new Map();
    try {
        const raw = localStorage.getItem(CACHE_KEY);
        if (raw) translationCache = new Map(Object.entries(JSON.parse(raw)));
    } catch { /* ignore */ }

    function saveCacheDebounced() {
        clearTimeout(state.cacheSaveTimer);
        state.cacheSaveTimer = setTimeout(() => {
            try {
                while (translationCache.size > MAX_CACHE) {
                    const oldest = translationCache.keys().next().value;
                    translationCache.delete(oldest);
                }
                localStorage.setItem(CACHE_KEY, JSON.stringify(Object.fromEntries(translationCache)));
            } catch { /* ignore */ }
        }, 800);
    }

    // ---------- Fixed Dictionary ----------
    const FIXED = {
        "월요일":"星期一","화요일":"星期二","수요일":"星期三","목요일":"星期四","금요일":"星期五","토요일":"星期六","일요일":"星期日",
        "월":"周一","화":"周二","수":"周三","목":"周四","금":"周五","토":"周六","일":"周日",
        "오전":"上午","오후":"下午","좋아요":"点赞","댓글":"评论","답글":"回复","공유":"分享",
        "닫기":"关闭","확인":"确认","취소":"取消","저장":"保存","로그인":"登录","회원가입":"注册","검색":"搜索"
    };

    // ---------- Utilities ----------
    const isKorean = text => /[가-힣]/.test(text);
    const ignoreTag = tag => ["SCRIPT","STYLE","NOSCRIPT","TEXTAREA","SVG","MATH","CODE","PRE"].includes(tag);
    const isVisible = el => el && (el.offsetParent !== null || getComputedStyle(el).position === "fixed");
    const inViewport = el => {
        const r = el.getBoundingClientRect();
        return r.top < window.innerHeight && r.bottom > 0;
    };

    // ---------- Messaging ----------
    function sendMessageWithTimeout(msg, timeout = 12000) {
        return new Promise((resolve, reject) => {
            let done = false;
            const timer = setTimeout(() => {
                if (done) return;
                done = true;
                reject(new Error("Timeout"));
            }, timeout);
            chrome.runtime.sendMessage(msg, res => {
                if (done) return;
                done = true;
                clearTimeout(timer);
                if (res?.success) resolve(res.result);
                else reject(new Error(res?.error || "Fail"));
            });
        });
    }

    async function batchTranslate(texts) {
        if (!texts.length) return [];
        try { return await sendMessageWithTimeout({ type: "translateBatch", texts }); }
        catch { return texts; }
    }

    // ---------- UI Update ----------
    function updateStatus(text, percent = 0) {
        if (state.statusEl) state.statusEl.textContent = text;
        if (state.progressEl) state.progressEl.style.width = `${Math.min(100, Math.max(0, percent))}%`;
    }

    // ---------- Collect Text Nodes ----------
    function collectTextNodes(root) {
        const result = [];
        if (!root) return result;
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode(node) {
                const parent = node.parentElement;
                if (!parent || parent.closest("#dju-translator-host")) return NodeFilter.FILTER_REJECT;
                if (ignoreTag(parent.tagName) || !isVisible(parent)) return NodeFilter.FILTER_REJECT;
                if (translatedTextNodes.has(node)) return NodeFilter.FILTER_REJECT;
                const text = node.textContent?.trim();
                if (!text || text.length > 1000 || !isKorean(text)) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            }
        });
        let node;
        while ((node = walker.nextNode())) result.push(node);
        return result;
    }

    // ---------- Collect Attribute Nodes ----------
    function collectAttributeNodes(root) {
        const result = [];
        if (!root.querySelectorAll) return result;
        const elements = root.querySelectorAll("input,button,[title],[placeholder]");
        for (const el of elements) {
            if (!isVisible(el)) continue;
            for (const attr of ["title","placeholder","value"]) {
                const val = el[attr];
                if (typeof val === "string" && val.trim() && isKorean(val)) {
                    const flag = `__dju_attr_${attr}`;
                    if (el[flag]) continue;          // 已采集过，防止重复
                    result.push({ element: el, attr, text: val });
                    el[flag] = true;                 // 标记
                }
            }
        }
        return result;
    }

    // ---------- Process Batch (text + attr) ----------
    async function processNodes(nodes) {
        if (!nodes.length) return;

        // 按原文去重（文本节点用 content，属性节点用 text）
        const textMap = new Map();   // originalText -> [node or {element,attr}]
        for (const item of nodes) {
            const original = item.nodeType === Node.TEXT_NODE ? item.textContent.trim() : item.text.trim();
            if (!textMap.has(original)) textMap.set(original, []);
            textMap.get(original).push(item);
        }

        const toTranslate = [];
        const resolved = new Map();   // original -> translated

        // 1) 固定翻译 & 缓存
        for (const [text, _] of textMap) {
            if (FIXED[text]) resolved.set(text, FIXED[text]);
            else if (translationCache.has(text)) resolved.set(text, translationCache.get(text));
            else toTranslate.push(text);
        }

        // 2) API批量
        if (toTranslate.length) {
            const results = await batchTranslate(toTranslate);
            toTranslate.forEach((orig, idx) => {
                const trans = results[idx];
                if (trans && trans !== orig) {
                    resolved.set(orig, trans);
                    translationCache.set(orig, trans);
                }
            });
            saveCacheDebounced();
        }

        // 3) 应用翻译并保存原始值
        for (const [original, items] of textMap) {
            const translated = resolved.get(original);
            if (!translated || translated === original) continue;

            for (const item of items) {
                try {
                    if (item.nodeType === Node.TEXT_NODE) {
                        // 文本节点
                        if (!modifiedTextNodes.has(item)) {
                            modifiedTextNodes.set(item, item.textContent);
                        }
                        item.textContent = translated;
                        translatedTextNodes.add(item);
                    } else {
                        // 属性节点
                        const { element, attr } = item;
                        if (!modifiedAttrElements.has(element)) {
                            modifiedAttrElements.set(element, {});
                        }
                        const attrs = modifiedAttrElements.get(element);
                        if (!(attr in attrs)) {
                            attrs[attr] = element[attr];
                        }
                        element[attr] = translated;
                    }
                } catch { /* ignore write errors */ }
            }
        }
    }

    // ---------- Queue Scheduler ----------
    async function processQueues() {
        if (state.processing) return;
        state.processing = true;
        state.translating = true;
        updateStatus("AI翻译中 0%", 0);

        while (state.visibleQueue.length || state.backgroundQueue.length) {
            let batch;
            if (state.visibleQueue.length) {
                batch = state.visibleQueue.splice(0, 20);
            } else {
                batch = state.backgroundQueue.splice(0, 10);
            }
            await processNodes(batch);
            state.completed += batch.length;
            const percent = Math.floor((state.completed / Math.max(state.total, 1)) * 100);
            updateStatus(`AI翻译中 ${percent}%`, percent);

            // 空闲时继续
            await new Promise(resolve => requestIdleCallback(resolve, { timeout: 50 }));
        }

        state.processing = false;
        state.translating = false;
        updateStatus("翻译完成", 100);
    }

    // ---------- Start Translation ----------
    async function translatePage() {
        if (state.translating) return;
        state.active = true;
        updateStatus("扫描页面中...", 5);

        const textNodes = collectTextNodes(document.body);
        const attrNodes = collectAttributeNodes(document.body);
        const allNodes = [...textNodes, ...attrNodes];

        if (!allNodes.length) {
            updateStatus("没有检测到韩文", 0);
            state.active = false;
            return;
        }

        state.visibleQueue = [];
        state.backgroundQueue = [];
        for (const node of allNodes) {
            const parent = node.nodeType === Node.TEXT_NODE ? node.parentElement : node.element;
            if (inViewport(parent)) state.visibleQueue.push(node);
            else state.backgroundQueue.push(node);
        }

        state.total = allNodes.length;
        state.completed = 0;
        processQueues();   // async but not awaited
    }

    // ---------- Restore Original ----------
    function restorePage() {
        // 中断所有任务
        state.visibleQueue = [];
        state.backgroundQueue = [];
        state.translating = false;
        state.processing = false;

        // 还原文本节点
        for (const [node, original] of modifiedTextNodes) {
            try { node.textContent = original; } catch { /* ignore */ }
        }
        modifiedTextNodes.clear();

        // 还原属性节点，同时清除采集标记
        for (const [element, attrs] of modifiedAttrElements) {
            for (const attr in attrs) {
                try { element[attr] = attrs[attr]; } catch { /* ignore */ }
                delete element[`__dju_attr_${attr}`];
            }
        }
        modifiedAttrElements.clear();

        translatedTextNodes = new WeakSet();   // 重置标记
        state.active = false;
        updateStatus("已恢复原文", 0);
    }

    // ---------- Mutation Observer ----------
    function startMutationObserver() {
        state.observer = new MutationObserver(mutations => {
            if (!state.active) return;
            clearTimeout(state.mutationTimer);
            state.mutationTimer = setTimeout(() => {
                const newNodes = [];
                for (const mut of mutations) {
                    for (const node of mut.addedNodes) {
                        if (node.nodeType !== Node.ELEMENT_NODE) continue;
                        if (node.closest?.("#dju-translator-host")) continue;
                        newNodes.push(...collectTextNodes(node));
                        newNodes.push(...collectAttributeNodes(node));
                    }
                }
                if (!newNodes.length) return;

                for (const node of newNodes) {
                    const parent = node.nodeType === Node.TEXT_NODE ? node.parentElement : node.element;
                    if (inViewport(parent)) state.visibleQueue.push(node);
                    else state.backgroundQueue.push(node);
                }
                state.total += newNodes.length;
                if (!state.processing) processQueues();
            }, 250);
        });
        state.observer.observe(document.body, { childList: true, subtree: true });
    }

    // ---------- Intersection Observer (懒翻译) ----------
    function startIntersectionObserver() {
        state.intersectionObserver = new IntersectionObserver(entries => {
            if (!state.active) return;
            for (const entry of entries) {
                if (!entry.isIntersecting) continue;
                const target = entry.target;
                // 节点可能是文本节点（但文本节点不能直接观察，我们观察的是父元素）
                // 这里观察的是我们在backgroundQueue中的元素？
                // 实际上我们应观察那些不在视口内的元素，当它们进入视口时触发翻译。
            }
        }, { threshold: 0 });
    }

    // 由于 IntersectionObserver 观察的目标必须是 Element，而我们的节点有文本节点和属性对象，
    // 更简单的方式是：在将节点放入 backgroundQueue 时，观察其父元素，进入视口后移入 visibleQueue。
    // 但为了保持简洁和性能，当前版本中我们仅依赖 MutationObserver 和主动扫描，可视优先已在初始分配时完成。
    // 故 IntersectionObserver 暂留空，后续可进一步优化。
    // 这里先移除不完整的实现，避免报错。
    // 在实际产品中，你可以对 backgroundQueue 中的元素进行观察。

    // ---------- UI (Shadow DOM) ----------
    function createUI() {
        if (document.getElementById("dju-translator-host")) return;
        const host = document.createElement("div");
        host.id = "dju-translator-host";
        host.style.cssText = "position:fixed;top:20px;left:20px;width:280px;z-index:2147483647;";
        document.body.appendChild(host);

        const shadow = host.attachShadow({ mode: "open" });
        shadow.innerHTML = `
        <style>
            *{box-sizing:border-box;margin:0;padding:0;}
            .box{
                background:rgba(18,18,22,.78); backdrop-filter:blur(18px);
                border-radius:18px; padding:16px; color:#fff;
                font-family:Inter,system-ui,sans-serif;
                border:1px solid rgba(255,255,255,.08);
                box-shadow:0 12px 40px rgba(0,0,0,.4); user-select:none;
            }
            .title{font-size:18px;font-weight:700;margin-bottom:12px;cursor:grab;}
            .title:active{cursor:grabbing;}
            .status{font-size:13px;opacity:.85;margin-bottom:10px;}
            .progress-bg{width:100%;height:6px;background:rgba(255,255,255,.08);border-radius:999px;overflow:hidden;margin-bottom:16px;}
            .progress{width:0%;height:100%;background:linear-gradient(90deg,#00c6ff,#0072ff);transition:width .25s;}
            .buttons{display:flex;gap:10px;}
            button{flex:1;border:none;border-radius:12px;padding:10px;cursor:pointer;font-weight:600;color:#fff;}
            .btn-translate{background:linear-gradient(90deg,#00c6ff,#0072ff);}
            .btn-restore{background:rgba(255,255,255,.1);}
            .footer{margin-top:12px;text-align:center;font-size:11px;opacity:.5;}
        </style>
        <div class="box">
            <div class="title" id="drag-bar">DJU AI Translator</div>
            <div class="status" id="status">等待翻译</div>
            <div class="progress-bg"><div class="progress" id="progress"></div></div>
            <div class="buttons">
                <button class="btn-translate" id="translate-btn">开始翻译</button>
                <button class="btn-restore" id="restore-btn">恢复原文</button>
            </div>
            <div class="footer">Enterprise v4</div>
        </div>`;

        state.statusEl = shadow.getElementById("status");
        state.progressEl = shadow.getElementById("progress");

        shadow.getElementById("translate-btn").addEventListener("click", translatePage);
        shadow.getElementById("restore-btn").addEventListener("click", restorePage);

        // Dragging
        const dragBar = shadow.getElementById("drag-bar");
        let dragging = false, startX, startY, initialLeft, initialTop;

        const onMouseMove = e => {
            if (!dragging) return;
            host.style.left = `${initialLeft + e.clientX - startX}px`;
            host.style.top = `${initialTop + e.clientY - startY}px`;
        };
        const onMouseUp = () => { dragging = false; };

        dragBar.addEventListener("mousedown", e => {
            dragging = true;
            startX = e.clientX; startY = e.clientY;
            initialLeft = parseInt(host.style.left) || 20;
            initialTop = parseInt(host.style.top) || 20;
            e.preventDefault();
        });
        document.addEventListener("mousemove", onMouseMove);
        document.addEventListener("mouseup", onMouseUp);
    }

    // ---------- Init ----------
    function init() {
        createUI();
        startMutationObserver();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();