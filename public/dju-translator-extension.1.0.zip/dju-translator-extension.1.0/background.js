const API_KEY = "sk-042a5dcb84bb4809a01fd9c462fba8b4";

const API_URL =
    "https://api.deepseek.com/chat/completions";

// =========================
// 批量翻译
// =========================

async function translateBatch(texts) {

    try {

        const prompt = `
你是专业韩语翻译助手。

请把下面韩文翻译成简体中文。

要求：
1. 保持顺序
2. 不要解释
3. 一行对应一行
4. 直接输出翻译结果

内容：

${texts.join("\n")}
`;

        const response =
            await fetch(API_URL, {

                method: "POST",

                headers: {

                    "Content-Type":
                        "application/json",

                    "Authorization":
                        `Bearer ${API_KEY}`

                },

                body: JSON.stringify({

                    model:
                        "deepseek-chat",

                    messages: [
                        {
                            role: "user",
                            content: prompt
                        }
                    ],

                    temperature: 0.2

                })

            });

        const data =
            await response.json();

        console.log(data);

        if (
            !data.choices ||
            !data.choices[0]
        ) {

            return texts;

        }

        let result =
            data.choices[0]
                .message.content;

        result =
            result
                .split("\n")
                .map(t => t.trim())
                .filter(Boolean);

        while (
            result.length <
            texts.length
        ) {

            result.push(
                texts[
                    result.length
                ]
            );

        }

        return result;

    }

    catch (err) {

        console.error(
            "翻译失败",
            err
        );

        return texts;

    }

}

// =========================
// 接收消息
// =========================

chrome.runtime.onMessage.addListener(

    (
        request,
        sender,
        sendResponse
    ) => {

        if (
            request.type ===
            "translateBatch"
        ) {

            translateBatch(
                request.texts
            )

            .then(result => {

                sendResponse({

                    success: true,

                    result

                });

            })

            .catch(err => {

                console.error(err);

                sendResponse({

                    success: false

                });

            });

            return true;

        }

    }

);