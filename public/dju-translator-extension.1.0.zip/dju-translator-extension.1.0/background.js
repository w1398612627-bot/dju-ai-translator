const API_KEY = "sk-042a5dcb84bb4809a01fd9c462fba8b4";

chrome.runtime.onMessage.addListener(
    (request, sender, sendResponse) => {

        if (
            request.type ===
            "translateBatch"
        ) {

            translateBatch(
                request.texts
            )

            .then(result => {

                sendResponse({
                    success: true,
                    result
                });

            })

            .catch(error => {

                console.log(error);

                sendResponse({
                    success: false,
                    error: error.toString()
                });

            });

            return true;
        }

    }
);

async function translateBatch(texts) {

    const joinedText =
        texts.join("\n---TEXT---\n");

    const response = await fetch(
        "https://api.deepseek.com/chat/completions",
        {
            method: "POST",

            headers: {

                "Content-Type":
                    "application/json",

                "Authorization":
                    `Bearer ${API_KEY}`

            },

            body: JSON.stringify({

                model:
                    "deepseek-chat",

                messages: [

                    {
                        role: "system",

                        content:
`你是专业韩语网页翻译助手。

规则：

1. 只翻译韩语
2. 不要解释
3. 保持原顺序
4. 用 ---TEXT--- 分隔返回
5. 不允许遗漏`
                    },

                    {
                        role: "user",

                        content:
                            joinedText
                    }

                ],

                temperature: 0.3

            })

        }
    );

    const data =
        await response.json();

    console.log(data);

    const result =
        data.choices?.[0]
        ?.message?.content;

    if (!result) {

        return texts;

    }

    return result.split(
        "\n---TEXT---\n"
    );
}