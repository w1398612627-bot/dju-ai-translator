chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  async function translate() {

    const clientId = "zexfzsv7en";
    const clientSecret = "1l27afeoT0GFq8GlsRpNYGMzGKQ3h9FSvE1gwfyC";

    try {

      const response = await fetch(
        "https://naveropenapi.apigw.ntruss.com/nmt/v1/translation",
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json",
            "X-NCP-APIGW-API-KEY-ID": clientId,
            "X-NCP-APIGW-API-KEY": clientSecret
          },

          body: JSON.stringify({
            source: "ko",
            target: "zh-CN",
            text: request.text
          })
        }
      );

      console.log("状态码:", response.status);

      const text = await response.text();

      console.log("服务器返回:");
      console.log(text);

      sendResponse({
        translatedText: text
      });

    } catch (error) {

      console.log(error);

      sendResponse({
        translatedText: error.toString()
      });

    }
  }

  translate();

  return true;
});